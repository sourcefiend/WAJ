package hr.tvz.smolcic.hardwareapp.DTOs;

public class HardwareDTO {

    String name;
    double price;

    public HardwareDTO(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}
