package hr.tvz.smolcic.hardwareapp.service;

import hr.tvz.smolcic.hardwareapp.DTOs.HardwareDTO;
import hr.tvz.smolcic.hardwareapp.command.HardwareCommand;
import hr.tvz.smolcic.hardwareapp.enums.HardwareType;
import hr.tvz.smolcic.hardwareapp.interfaces.services.IHardwareService;
import hr.tvz.smolcic.hardwareapp.model.Hardware;
import hr.tvz.smolcic.hardwareapp.repository.HardwareRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HardwareService implements IHardwareService {

    private final HardwareRepository hardwareRepository;

    public HardwareService(HardwareRepository hardwareRepository) {
        this.hardwareRepository = hardwareRepository;
    }

    @Override
    public List<HardwareDTO> findAll() {
        return this.hardwareRepository.findAll().stream().map(this::mapHardwareToDTO).collect(Collectors.toList());
    }

    @Override
    public Optional<HardwareDTO> findByCode(String code) {
        return this.hardwareRepository.findByCode(code).map(this::mapHardwareToDTO);
    }

    @Override
    public Optional<HardwareDTO> save(HardwareCommand command) {
        return this.hardwareRepository.save(mapHardwareCommandToHardware(command)).map(hw -> new HardwareDTO(hw.getName(), hw.getPrice()));
    }

    @Override
    public Optional<HardwareDTO> delete(String code) {
        return this.hardwareRepository.delete(code).map(hw -> mapHardwareToDTO(hw));
    }


    private HardwareDTO mapHardwareToDTO(final Hardware hardware) {
        return new HardwareDTO(hardware.getName(), hardware.getPrice());
    }

    private Hardware mapHardwareCommandToHardware(final HardwareCommand hardwareCommand) {
        return new Hardware(hardwareCommand.getName(), hardwareCommand.getCode(), hardwareCommand.getPrice(), HardwareType.valueOf(hardwareCommand.getHardwareType()), hardwareCommand.getStockAmount());
    }
}
