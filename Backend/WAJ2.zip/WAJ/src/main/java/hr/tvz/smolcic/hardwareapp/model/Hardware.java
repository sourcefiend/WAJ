package hr.tvz.smolcic.hardwareapp.model;

import hr.tvz.smolcic.hardwareapp.enums.HardwareType;

public class Hardware {

    String name;
    String code;
    double price;
    HardwareType hardwareType;
    Integer stockAmount;

    public Hardware(String name, String code, double price, HardwareType hardwareType, Integer stockAmount) {
        this.name = name;
        this.code = code;
        this.price = price;
        this.hardwareType = hardwareType;
        this.stockAmount = stockAmount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public HardwareType getHardwareType() {
        return hardwareType;
    }

    public void setHardwareType(HardwareType hardwareType) {
        this.hardwareType = hardwareType;
    }

    public Integer getStockAmount() {
        return stockAmount;
    }

    public void setStockAmount(Integer stockAmount) {
        this.stockAmount = stockAmount;
    }
}
