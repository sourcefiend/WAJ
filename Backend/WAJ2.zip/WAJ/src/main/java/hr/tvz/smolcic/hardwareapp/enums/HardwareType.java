package hr.tvz.smolcic.hardwareapp.enums;

public enum HardwareType {
    CPU,
    GPU,
    MBO,
    RAM,
    STORAGE,
    OTHER
}
