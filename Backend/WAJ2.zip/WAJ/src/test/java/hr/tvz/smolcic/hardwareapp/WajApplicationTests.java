package hr.tvz.smolcic.hardwareapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WajApplicationTests {

    @Test
    void contextLoads() {
    }

}
